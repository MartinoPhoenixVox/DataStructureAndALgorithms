#include <iostream>
using namespace std;
#include "polynomial-Array.h" 

int main() {
	
	return 0;
}